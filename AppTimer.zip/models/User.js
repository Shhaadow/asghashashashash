const mongoose = require('mongoose');

const UserSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true
  },
  email: {
    type: String,
    required: true
  },
  admin: {
    type: Boolean,
    default: false
  },
  password: {
    type: String,
    required: true
  },
  password2: {
    type: String,
    required: true
  },
  monitors: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: "Monitor",
  }],
  date: {
    type: Date,
    default: Date.now
  }
});

const User = mongoose.model('User1', UserSchema);

module.exports = User;
