const mongoose = require('mongoose');

const MonitorSchema = new mongoose.Schema({
  owner: {
    type: String,
    required: true
  },
  name: {
    type: String,
    required: true
  },
  url: {
    type: String,
    required: true
  },
  date: {
    type: Date,
    default: Date.now
  },
  status: {
    type: Boolean,
    default: true
  },
  pause: {
    type: Boolean,
    default: false
  },
  ssl: {
    type: Boolean,
    default: false
  },
  ssl_days: {
    type: Number,
    default: 0
  }
});

const Monitor = mongoose.model('Monitor', MonitorSchema);

module.exports = Monitor;
