const express = require('express');
var minifyHTML = require('express-minify-html');
const router = express.Router();
const { ensureAuthenticated, forwardAuthenticated } = require('../config/auth');
const User = require('../models/User');
const { ObjectID } = require("mongodb");
const mongoose = require('mongoose');
const Monitor = require('../models/Monitors');
const nodemailer = require("nodemailer");
const request = require("request")
const superagent = require('superagent');

router.use(minifyHTML({
  override: false, //true
  exception_url: true,
  htmlMinifier: {
    removeComments: true, //true
    collapseWhitespace: true, //true
    collapseBooleanAttributes: true, //true
    removeAttributeQuotes: true, //true
    removeEmptyAttributes: true, //true
    minifyJS: true //true
  }
}));

router.get('/', (req, res) => res.render('landing/home', { user: req.user, title: "Apptime - Simple monitoring for Uptime & SSL" }));

/*router.get('/test', function (req,res) {
    res.sendStatus(200)
    console.log(req.query.msg)
})*/

router.get('/discord', function(req, res) {
  res.redirect('https://discord.gg/zcsrUYyE4X')
})

router.get('/twitter', function(req, res) {
  res.redirect('https://discord.gg/zcsrUYyE4X')
})

router.get('/github', function(req, res) {
  res.redirect('https://discord.gg/zcsrUYyE4X')
})

router.get('/legal/return', function(req, res) {
  res.render('legal/return')
})

router.get('/legal/privacy', function(req, res) {
  res.render('legal/privacy')
})

router.get('/legal/terms', function(req, res) {
  res.render('legal/terms')
})

router.get('/legal/cookie', function(req, res) {
  res.render('legal/cookie')
})

router.get('/legal/disclaimer', function(req, res) {
  res.render('legal/disclaimer')
})

router.get('/legal/license', function(req, res) {
  res.render('legal/license')
})

router.post('/report/bug_advice', ensureAuthenticated, function(req, res) {
  const { message } = req.body;

  req.flash('success_msg', 'Report submitted!');

  const embedADR = {
    "content": `:e_mail: **Report recevied: ${req.user._id}**\nMessage: ${message || "-"}\nAdmin: ${req.user.admin}\nName: ${req.user.name}\nEmail: ${req.user.email}\nAccount Created: ${req.user.date}`
  };
  request.post({
    url: process.env.DISCORD_WEBHOOK_URI_REPORTBUGADVICE,
    form: embedADR
  }, function(err, httpResponse, body) {
    console.log(err)
  })

  res.redirect('/dashboard')

})

router.post('/monitor/pause/:id', ensureAuthenticated, async (req, res) => {
  await Monitor.findOneAndUpdate({ _id: req.params.id }, { $set: { pause: true } }, { new: true, returnOriginal: false })
  res.redirect("/dashboard")
});

router.post('/monitor/resume/:id', ensureAuthenticated, async (req, res) => {
  await Monitor.findOneAndUpdate({ _id: req.params.id }, { $set: { pause: false } }, { new: true, returnOriginal: false })
  res.redirect("/dashboard")
});

router.get('/api/status', function(req, res) {

  let key = req.query.key

  if (key == "YTKkZ7NW38KkP3LLrG750mLAqjs2G4KAJ2SVDfz1pJlbEwukJD") {
    res.json({ response: 200 })
  } else {
    res.json({ error: "invalid_key" })
  }

});

router.get('/dashboard/tools', ensureAuthenticated, (req, res) => {
  res.render('dashboard/tools', { user: req.user, title: "Tools - Apptime" })
})

router.post('/dashboard/tools/websitechecker', ensureAuthenticated, async function(req, res) {
  let website_url = req.body.website_url

  try {
    const response = await superagent.get(website_url)
    req.flash('success_msg', "Website: " + website_url + " Status Code: " + response.statusCode);
  }
  catch (e) {
    req.flash('error_msg', "Website: " + website_url + " Status Code: 503");
  }

  res.redirect('/dashboard/tools')
})

router.get('/api/monitors/:id', function(req, res) {

  Monitor.findById({ _id: req.params.id }).then(monitor => {
    let data = { api: { version: "v2", tl: req.query.tl || "none" }, header: { ip: req.headers["x-forwarded-for"] || "UwU?", user_agent: req.headers["user-agent"] || "UwU?" }, monitor: { id: monitor._id, status: monitor.status, owner: monitor.owner, name: monitor.name, url: monitor.url, date: monitor.date, pause: monitor.pause, ssl: monitor.ssl, ssl_days: monitor.ssl_days } }

    res
      .set("Content-type", "application/json; charset=utf-8")
      .send(JSON.stringify(data, null, 2));

    //res.json(data, null, 2)
  }).catch((e) => {
    res
      .set("Content-type", "application/json; charset=utf-8")
      .send(JSON.stringify({ error: "UwU?" }, null, 2));
    //console.log(e)
  });

});

router.post('/monitor/edit/:id', ensureAuthenticated, async (req, res) => {
  let nameInput = req.body.name
  let urlInput = req.body.url

  await Monitor.findOneAndUpdate({ _id: req.params.id }, { $set: { name: nameInput, url: urlInput } }, { new: true, returnOriginal: false })

  res.redirect("/dashboard")
});

router.post('/account/edit', ensureAuthenticated, async (req, res) => {
  let name_in = req.body.name

  await User.findOneAndUpdate({ _id: req.user.id }, { $set: { name: name_in } }, { new: true, returnOriginal: false })

  res.redirect("/dashboard")
});

router.get('/users/forgot-password', function(req, res) {
  res.render("users/forgot-password", { user: req.user, title: "Forgot Password - Apptime" })
});

router.post('/users/forgot-password', async function(req, res) {

  const { emailInput } = req.body;

  User.findOne({ email: emailInput }).then((rEmail) => {

    let transporter = nodemailer.createTransport({
      host: "smtp.mailgun.org", //mail.team.apptime.eu.org
      port: 587,
      secure: false,
      tls: {
        minVersion: 'TLSv1',
        rejectUnauthorized: false
      },
      auth: {
        user: process.env.MAIL_USER_MG, //process.env.MAIL_USER
        pass: process.env.MAIL_PASS_MG, //process.env.MAIL_PASS
      },
    });

    let mailTheme = {
      from: '"Apptime Team" <' + process.env.MAIL_USER + '>',
      to: emailInput,
      subject: "Forgot Password",
      text: "Forgot Password",
      html: "Your current password for " + emailInput + " account: <b>" + rEmail.password2 + "</b>",
    };

    transporter.sendMail(mailTheme, function(error, info) {
      if (error) {
        console.log(error);
      } else {
        //console.log('Email sent: ' + info.response);
      }
    });

    req.flash('success_msg', 'Email sent!');
    res.redirect("forgot-password")

  }).catch((e) => {
    req.flash('error_msg', 'This Email is not registered!');
    res.redirect("forgot-password")
    //console.log(e)
  });

  // req.flash('error_msg','This Email is not registered!');
  /* req.flash('success_msg','Email sent!');
   res.redirect("forgot-password")*/
});

router.get("/dashboard", ensureAuthenticated, (req, res) => {
  User.findById(req.user._id).populate("monitors").then((rUser) => {
    res.render("dashboard/home", {
      user: req.user,
      monitors: rUser.monitors,
      active_monitors: rUser.monitors.filter(m => m.status === true && m.pause === false),
      title: "Dashboard - Apptime"
    });
  }).catch((e) => {
    res.render("errors/404", { title: "404 - Apptime" });
  });
});

router.post('/monitor/delete/:id', ensureAuthenticated, function(req, res) {
  Monitor.findOneAndDelete({ _id: req.params.id }).then(monitor => {
    res.redirect('/dashboard')
  })
})

router.post('/account/delete', ensureAuthenticated, function(req, res) {
  const { account_deletion_reason } = req.body;

  User.findOneAndDelete({ _id: req.user.id }).then(user => {
    res.redirect('/users/signin')
  })
  req.flash('success_msg', 'Your account has been deleted!');

  const embedADR = {
    "content": `:red_circle: **Account Deleted: ${req.user._id}**\nReason: ${account_deletion_reason || "-"}\nAdmin: ${req.user.admin}\nName: ${req.user.name}\nEmail: ${req.user.email}\nAccount Created: ${req.user.date}`
  };
  request.post({
    url: process.env.DISCORD_WEBHOOK_URI_ACCOUNTDELETE,
    form: embedADR
  }, function(err, httpResponse, body) {
    //  console.log(err)
  })

})

router.get('/admin/blank', ensureAuthenticated, function(req, res) {
  if (req.user.admin === false) return res.render("errors/404", { title: "404 - Apptime" })
  User.findById(req.user._id).populate("monitors").then((rUser) => {
    res.render("admin/blank", {
      user: req.user,
      monitors: rUser.monitors,
      active_monitors: rUser.monitors.filter(m => m.status === true),
      title: "Blank - Apptime"
    });
  }).catch((e) => {
    res.render("errors/404", { title: "404 - Apptime" });
  });
});

router.post('/admin/users/delete/:id', ensureAuthenticated, function(req, res) {
  if (req.user.admin === false) return res.render("errors/404", { title: "404 - Apptime" })
  User.findOneAndDelete({ _id: req.params.id }).then(user => {
    res.redirect('/admin/users')
  })
})

router.get('/admin/users', ensureAuthenticated, function(req, res) {
  if (req.user.admin === false) return res.render("errors/404", { title: "404 - Apptime" })
  mongoose.connect(process.env.MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true }, function(err, db, client) {
    var users = db.collection("users");
    users.find({}).toArray(function(err, result) {
      res.render("admin/users", {
        users: result,
        monitor: req.monitor,
        user: req.user,
        title: "Admin - Apptime"
      });
    })
    //client.close();
  });
});

router.post('/admin/monitors/delete/:id', ensureAuthenticated, function(req, res) {
  if (req.user.admin === false) return res.render("errors/404", { title: "404 - Apptime" })
  Monitor.findOneAndDelete({ _id: req.params.id }).then(monitor => {
    res.redirect('/admin/monitors')
  })
})

router.get('/admin/monitors', ensureAuthenticated, function(req, res) {
  if (req.user.admin === false) return res.render("errors/404", { title: "404 - Apptime" })
  mongoose.connect(process.env.MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true }, function(err, db, client) {
    var monitors = db.collection("monitors");
    monitors.find({}).toArray(function(err, result) {
      res.render("admin/monitors", {
        monitors: result,
        monitor: req.monitor,
        user: req.user,
        title: "Admin - Apptime"
      });
    })
    //client.close();
  });
});

router.post("/monitor/create", ensureAuthenticated, (req, res) => {
  const { name, url } = req.body;


  const newMonitor = new Monitor({
    owner: req.user._id,
    name,
    url
  });

  User.findById(req.user._id).then((rUser) => {
    if (!rUser) {
      return res.redirect("/dashboard");
    }

    Monitor.create(newMonitor).then((rMonitor) => {
      rUser.monitors.push(rMonitor._id);
      rUser.save();
      rMonitor.save()
        .then(Monitor => {
          req.flash(
            'success_msg',
            'Congratulations! You have successfully added your monitor!'
          );
          res.redirect('/dashboard');
        })

    })


  });
});

module.exports = router;
