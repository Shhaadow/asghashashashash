const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const passport = require('passport');
const User = require('../models/User');
const { forwardAuthenticated } = require('../config/auth');

router.get('/signin', forwardAuthenticated, (req, res) => res.render('users/signin', { title: "Sign In - Apptime" }));

router.get('/signup', forwardAuthenticated, (req, res) => res.render('users/signup', { title: "Sign Up - Apptime" }));

router.post('/signup', (req, res) => {
 // console.log(req.body)
  const { name, email, password, password2 } = req.body;
  let errors = [];

  if (!name || !email || !password || !password2) {
    errors.push({ msg: 'Please Fill All!' });
  }

  if (password != password2) {
    errors.push({ msg: 'The passwords you entered do not match!' });
  }

  if (password.length < 6) {
    errors.push({ msg: 'A password can be at least 6 characters!' });
  }

  if (errors.length > 0) {
    res.render('users/signup', {
      errors,
      name,
      email,
      password,
      password2,
      title: "Sign Up - Apptime"
    });
  } else {
    User.findOne({ email: email }).then(user => {
      if (user) {
        errors.push({ msg: 'This email is already registered!' });
        res.render('users/signup', {
          errors,
          name,
          email,
          password,
          password2,
          title: "Sign Up - Apptime"
        });
      } else {
        const newUser = new User({
          name,
          email,
          password,
          password2
        });

        bcrypt.genSalt(10, (err, salt) => {
          bcrypt.hash(newUser.password, salt, (err, hash) => {
            if (err) throw err;
            newUser.password = hash;
            newUser.password2;
            newUser
              .save()
              .then(user => {
                req.flash(
                  'success_msg',
                  'You have successfully signup, signin now!'
                );
                res.redirect('/users/signin');
              })
              .catch(err => console.log(err));
          });
        });
      }
    });
  }
});

router.post('/signin', (req, res, next) => {
  passport.authenticate('local', {
    successRedirect: '/dashboard',
    failureRedirect: '/users/signin',
    failureFlash: true
  })(req, res, next);
});

router.get('/signout', (req, res) => {
  req.logout();
  req.flash('success_msg', 'You signed out!');
  res.redirect('/users/signin');
});

module.exports = router;
