const express = require('express');
const request = require("request");
const expressLayouts = require('express-ejs-layouts');
const mongoose = require('mongoose');
const passport = require('passport');
const flash = require('connect-flash');
const session = require('express-session');
const Monitor = require('./models/Monitors');
const User = require('./models/User');
const nodemailer = require("nodemailer");
const app = express();
const path = require("path");
app.use(express.static("public"));
app.use("/css", express.static(path.resolve(__dirname + `/stylesheets/css`)));
app.use("/js", express.static(path.resolve(__dirname + `/stylesheets/js`)));


require('./config/passport')(passport);

const db = require('./config/keys').mongoURI;

const options = {
  useNewUrlParser: true,
  useCreateIndex: true,
  autoIndex: true,
  bufferMaxEntries: 0,
  connectTimeoutMS: 10000,
  socketTimeoutMS: 45000,
  useUnifiedTopology: false,
  useFindAndModify: false,
  autoReconnect: true,
  reconnectTries: Number.MAX_VALUE,
  reconnectInterval: 500
}

mongoose
  .connect(
    db,
    options
  )
  .then(() => console.log('MongoDB Connected'))
  .catch(err => console.log(err));

app.set('view engine', 'ejs');

app.use(express.urlencoded({ extended: true }));

app.use(
  session({
    secret: 'secret',
    resave: true,
    saveUninitialized: true
  })
);

app.use(passport.initialize());
app.use(passport.session());

app.use(flash());

app.use(function(req, res, next) {
  res.locals.success_msg = req.flash('success_msg');
  res.locals.error_msg = req.flash('error_msg');
  res.locals.error = req.flash('error');
  next();
});

app.use('/', require('./routes/index.js'));
app.use('/users', require('./routes/users.js'));

const http = require('http');
const fetch = require('node-fetch');

//ssl monitoring sections
/*const cert = require('certificate-expiry');
setInterval(() => {
  Monitor.find({}, function(err, res) {
    if (err) console.log(err)
    if (!res) return;
    res.forEach(res => {
      if (res.pause === false) {
        var domain = res.url
        var regex = "https://";
        cert.daysLeft(domain.replace(regex, ''), async (err, daysLeft) => {
          if (err) {
            await Monitor.findOneAndUpdate({ _id: res._id }, { $set: { ssl: false, ssl_days: 0 } }, { new: true, returnOriginal: false })
          } else {
            await Monitor.findOneAndUpdate({ _id: res._id }, { $set: { ssl: true, ssl_days: daysLeft } }, { new: true, returnOriginal: false })
          }
        });
      }
    })
  })
}, 300000) //180000 = 3dk | 10800000 = 3sa | 180000 = 5dk*/

//down statuses sections
/*setInterval(() => {
  Monitor.find({}, function(err, res) {
    if (err) console.log(err)
    if (!res) return;
    res.forEach(res => {
      if (res.pause === false) {
        request(res.url, async function(error, response, body) {
          await Monitor.findOneAndUpdate({ _id: res._id }, { $set: { status: true } }, { new: true, returnOriginal: false })
          if (error) {
            await Monitor.findOneAndUpdate({ _id: res._id }, { $set: { status: false } }, { new: true, returnOriginal: false })
          }
        });
      }
    })
  })
}, 60000)*/

//main uptime sections
setInterval(() => {
  Monitor.find({}, function(err, res) {
    if (err) console.log(err)
    if (!res) return;
    res.forEach(res => {
      if (res.pause === false) {
        request(res.url, async function(error, response, body) {
        });
      }
    })
  })
}, 60000)

/*setInterval(() => {
  var query = { url: "https://unlinedflimsyconditional-2.hasanalt.repl.co/dstat" };
  Monitor.collection.remove(query);
  console.log(query + " silindi")
}, 1000)*/


const PORT = process.env.PORT || 5000;

app.listen(PORT, console.log(`Server started on port ${PORT}`));


app.get('/*', function(req, res) {
  res.render("errors/404", { title: "404 - Apptime" })
})

  