$('a.edit').click(function (e) {
    e.preventDefault();
    var tr = $(this).closest('tr'),
        modal = $('#editMonitor');
    $.getJSON('/api/monitors/' + tr.data('id'), function (data) {
        modal.find('form').attr('action', '/monitor/edit/' + tr.data('id') );
        modal.find('[name=name]').val(data.monitor.name);
        modal.find('[name=url]').val(data.monitor.url);
        modal.modal('show');
    });
});